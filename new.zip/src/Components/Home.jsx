import React from "react";
import { Container } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import "./Home.css";

const Home = () => {
  const navigate = useNavigate();

  return (
    <Container fluid className="homeContainer">
      <Container className="back-home">
        <div className="home-content">
          <b className="text-top">I'm a</b>
          <br />
          <b className="text-sec">
            MERN Full Stack Web Developer.
          </b>
          <br />
          <button
            className="button-project"
            onClick={() => navigate("/projects")}
          >
            Previous Projects
          </button>
        </div>
      </Container>
    </Container>
  );
};

export default Home;
